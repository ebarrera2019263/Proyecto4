import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class carro4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class carro4 extends Actor
{
    /**
     * Act - do whatever the carro4 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int speed;
    
    public carro4(int v){
        speed = v;
    }

    public void act()
    {
        
        //turn(20);
        if (Greenfoot.isKeyDown("a"))
        {
            
            if(getX()>150+50)
                setLocation(getX() - 5, getY());
        }
        if (Greenfoot.isKeyDown("d"))
        {
            if(getX()<701-50)
                setLocation(getX() + 5, getY());
        }
        if (Greenfoot.isKeyDown("w"))
        {
            //arriba
            if(getY() > 172)
                setLocation(getX(), getY()-2);
        }
        if (Greenfoot.isKeyDown("s"))
        {
            if(getY() < 801)
                setLocation(getX(), getY()+4);
        }
        checkCollision();
    }
    
    public void checkCollision(){
        Actor collided = getOneIntersectingObject(carro1.class);
        Actor collided3 = getOneIntersectingObject(carro3.class);
        if (collided != null || collided3 != null)
        {
          getWorld().removeObject(collided);
          getWorld().removeObject(this);
          Greenfoot.stop();
        }
    }
    
    public void aumenta_velocidad(){
        speed++;
    }
}
